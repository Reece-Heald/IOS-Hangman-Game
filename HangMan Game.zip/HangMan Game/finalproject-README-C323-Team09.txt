﻿CSCI-C323 / Spring 2022
Final Project
3:00pm Section, Team 9 - Saffron
Andrew Bathija - abathija
Reece Heald - rmheald
Max Rodriguez - maxrodri


For the final project, our group has decided to create a word guessing game that is similar to Hangman and Wordle. There will be a list of 15 words, and every time the app is loaded, the app will choose a “correct word” randomly from the list. The user will have an input text box, submit guess button, and keyboard in the game view controller to guess any word, and the app will output which letters of the guessed word are contained in the correct word. The user has 10 total attempts to guess the correct word, and the user can reset the game by clicking the new word button at any time. If the user guesses correctly in a new low record number of attempts, there is a SpriteKit animation to congratulate the new personal record. The record is kept track of using persistent storage. The user will have a category hint and letter hint buttons in the hint view controller to reveal two hints for the correct word. The user will be able to view previous guesses and the number of letters correct in each guess in the history table view controller. There is LoFi music constantly playing in the background.


Xcode Version 13.1.2


1. Model-View-Controller
   1. GuessTheWordModel.swift
   2. GameViewController.swift, HintViewController.swift, PreviousGuessesTableViewController.swift
   3. Main
2. User Interface
   1. Input
      1. GameViewController - UITextField, Keyboard, Submit Guess Button, New Word Button
      2. HintViewController - Category Hint Button, Letter Hint Button
   2. Output
      1. GameViewController - UILabel for correct letters
      2. HintViewController - UILabel for category hint, UILabel for letter hint
      3. PreviousGuessesTableViewController - table view cell for previous guesses and letters correct in each guess
   3. 3 Views
      1. GameViewController.swift, HintViewController.swift, PreviousGuessesTableViewController.swift
   4. ContainerViewController
      1. TabBarControllerViewController.swift
   5. TableViewController
      1. PreviousGuessesTableViewController.swift
3. Restrictions
   1. Yes, our project is different from any app seen during class time, does not use any server-side connections, and does not use any 3rd-party cross-platform API
4. Persistent Local Data Storage
   1. GameViewController
   2. createDirectory(), createHighscoreFile(), getDocumentDirectory(), readFile()
5. iOS Frameworks / Features
   1. AVAudioPlayer
      1. GameViewController
      2. viewDidLoad()
   2. UserNotifications
      1. GameViewController
      2. viewDidLoad()
6. SpriteKit
   1. GameViewController, CongratsScene
   2. didMove(), submitGuessButton()


Changes 
* AVFoundation
   * Why - Went in a different direction for the design
   * What - Removed and replaced with AVAudioPlayer
   * When - Before Assignment 04
   * Where - GameViewController, viewDidLoad()
* AVPlayer
   * Why - Went in a different direction for the design
   * What - Plays background lofi music instead of congratulations audio
   * When - Before Assignment 04
   * Where - GameViewController, viewDidLoad()