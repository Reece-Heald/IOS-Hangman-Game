//
//  SKViewController.swift
//  GuessTheWord
//    Reece Heald - rnheald
//    Andrew Bathija - abathija
//    Max rodriguez - maxrodri
//    App Name: Guess The Word
//    Due Date: 5/5/22

import Foundation
import UIKit
import SpriteKit

class SKViewController: UIViewController{
    
    var scene: CongratsScene?
    
    override func loadView() {
           super.loadView()
           self.view = SKView()
           self.view.bounds = UIScreen.main.bounds
       }
    override func viewDidAppear(_ animated: Bool) {
           super.viewDidAppear(animated)
           setupScene()
       }
    
    
    
func setupScene() {
       if let view = self.view as? SKView, scene == nil {
           let scene = CongratsScene(size: view.bounds.size)
           view.presentScene(scene)
           self.scene = scene
       }
    
    isDone()
   }
    
    
    func isDone(){
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "VC") as! GameViewController

        self.navigationController?.pushViewController(secondViewController, animated: true)
    }
    
}
