//
//  GameViewController.swift
//  GuessTheWord
//
//    Reece Heald - rnheald
//    Andrew Bathija - abathija
//    Max rodriguez - maxrodri
//    App Name: Guess The Word
//    Due Date: 5/5/22

//get all classes needed for noticifications
import UIKit
import AVFoundation

import UserNotifications
import GLKit


class GameViewController: UIViewController, UITextFieldDelegate {
    
    let lAppDelegate = UIApplication.shared.delegate as! AppDelegate
    var myGuessTheWordModel: GuessTheWordModel!
    
    //var for guesses allowed
    var guessesAllowed = 10

    //var for the word user typed in
    var wordGuessed = ""
    
    //var for the current word index
    var currWordIndex = Int.random(in: 0 ... 6)
    
    //var for displaying correct letters
    var numOfEachLettersCorrect = 0
    
    //var for checking how many letter u got right in word
    var numOfLettersCorrectInWord = 0
    
    var correctWord = ""
    
    var correctCategory = ""

    var correctChars = ""
    
    var uniques = ""
    
    var newWordFlag = false
    
    var highestScore = 0
    @IBOutlet weak var highestScoreLabel: UILabel!
    var theFolderNameURLWithPath = URL(fileURLWithPath: "")
    let lFM = FileManager()
    
    @IBOutlet weak var wordCorrectLabel: UILabel!
        
    //no need to edit
    @IBOutlet weak var welcomeTitle: UILabel!
    //no need to edit
    
    @IBOutlet weak var guessesLeft: UILabel!
    
    //no need to edit
    @IBOutlet weak var guessTextFieldoutlet: UITextField!
    
    
    //no need to edit
    @IBOutlet weak var lettersCorrect: UILabel!
    
    //no need to edit
    @IBOutlet weak var submitGuess: UIButton!
    
    //TODO: decrement each time submit guess is clicked DONE *****
    @IBOutlet weak var guessesLeftnum: UILabel!
    
    //no need to edit
    @IBOutlet weak var newWord: UIButton!
    
    //TODO: set the number to how many same letters occur in user guess, to correct word each time submit guess button is clicked. DONE *****
    @IBOutlet weak var lettersCorrectnum: UILabel!
    
    
    
    @IBAction func newWordPressed(_ sender: Any) {
        print("test")
        newWordFlag = true
        
        //reference to the model
        let lAppDelegate = UIApplication.shared.delegate as! AppDelegate
        myGuessTheWordModel = lAppDelegate.myGuessTheWordModel
        
        //reset word correct label
        wordCorrectLabel.backgroundColor = UIColor.systemTeal
        wordCorrectLabel.text = ""
        
        //resetting all variables used in submitguess button and correct letters in model
        correctChars = ""
        uniques = ""
        myGuessTheWordModel.correctLetters = []
        
        //changing background back to regular
        guessesLeftnum.backgroundColor = UIColor.systemTeal
        
        //resetting numLetters Correct to none
        numOfEachLettersCorrect = 0
        
        //storing highest score
        
        
        // resetting guesses allowed.
        guessesAllowed = 10
        guessesLeftnum.text = String(guessesAllowed)
        
        lettersCorrectnum.text = ""
        
        //switching word to random one in array we have for words
        myGuessTheWordModel.setRandIndex()
        correctWord = myGuessTheWordModel.newWord()
        
        //reset hints
        myGuessTheWordModel.setHintsRemaining()
        
        myGuessTheWordModel.previousGuesses.removeAll()
        
        
    }
    
    @IBAction func guessTextField(_ sender: Any) {
        
    }
    
    
    @IBAction func submitGuessButton(_ sender: Any) {
        
        
        
        newWordFlag = false
        //reference to the model
        let lAppDelegate = UIApplication.shared.delegate as! AppDelegate
       // var myGuessTheWordModel = lAppDelegate.myGuessTheWordModel
        
        //This is to decrement the guesses allowed each time submit is pressed.
        if (guessesAllowed > 0) {
            guessesAllowed = guessesAllowed - 1;
            guessesLeftnum.text = String(guessesAllowed)
        }
        if (guessesAllowed == 0){
            guessesLeftnum.backgroundColor = UIColor.red
        }
        
        //adds the guess to the previous guess array and resets the guessTextField back to blank, and stores guess in temp var
        myGuessTheWordModel.previousGuesses.append(guessTextFieldoutlet.text!)
        var temp = guessTextFieldoutlet.text!
        guessTextFieldoutlet.text = ""
        
        //if letter is in the word it displays it in lettersCorrectum
        numOfEachLettersCorrect = numOfEachLettersCorrect + 1
        
        //if there is more than one correct letter it adds a , if not then it just displays it
        myGuessTheWordModel.lettersCorrect(guess: temp, correct: correctWord)
        
        //var correctChars = ""
        
        for i in myGuessTheWordModel.correctLetters {
            correctChars += String(i)
        }
        
        // var uniques = ""
        
        for i in correctChars {
            if (uniques.contains(i) == false) {
                uniques += String(i)
            }
        }
        
        if guessesLeftnum.text == String(10) {
            uniques == ""
        }
        
        lettersCorrectnum.text = uniques
        
        if(temp == correctWord){
            wordCorrectLabel.backgroundColor = UIColor.green
            wordCorrectLabel.text = "Congrats, you got the word corrrect!"
            if(highestScore < guessesAllowed){
                highestScore = 10 - guessesAllowed
            
                highestScoreLabel.text = String(highestScore)
                
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

                let SKViewViewController = storyBoard.instantiateViewController(withIdentifier: "SKView") as! SKViewController

                self.present(SKViewViewController, animated:true, completion:nil)
            }
            self.createHighscoreFile()
            
        }
    }
    
    //for music
    var player:AVAudioPlayer = AVAudioPlayer()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //dismiss keyboard
        
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        self.view.addGestureRecognizer(tap)
        
        self.createDirectory()
        highestScoreLabel.text = String(self.readFile())
        
        myGuessTheWordModel = lAppDelegate.myGuessTheWordModel
        // Have the guesses Left Number start at loadout.
        guessesLeftnum.textAlignment = .center
        guessesLeftnum.text = String(guessesAllowed)
    
        
        correctWord = myGuessTheWordModel.correctWord()
        
        
        //Creaitng reference to the notification center
        let center = UNUserNotificationCenter.current()
        
        //asking the user for permission of notificationa
        center.requestAuthorization(options: [.alert, .sound]) {
            (granted, error) in
        }
        
        // creating the content of the notification that the user will see
        let content = UNMutableNotificationContent()
        content.title = "Notification"
        content.body = "Thanks for playing HangMan!"
        
        // This is the notification trigger, will take 10 seconds for it to pop up.
        let date = Date().addingTimeInterval(10)
        
        //shows current date and uses time when it wants to appear
        let dateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
        
        //passes in date components and dignifies it doesnt repeat
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        
        //quick ID that gives unique identifier
        let uuidString = UUID().uuidString
        
        //packaging everything into a notification request
        let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
        
        //registering request with notification center
        center.add(request) {
            (error) in
        }
        
        //play Music in background lofi, and even plays when you press home button. 
        
        do
        {
            let audioPath = Bundle.main.path(forResource: "Lofi", ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!) as URL)
        }
        catch
        {
            //PROCESS ERROR
        }
        
        let session = AVAudioSession.sharedInstance()
        
        do
        {
            try session.setCategory(AVAudioSession.Category.playback)
        }
        catch
        {
            
        }
        
        player.play()
        
        // Do any additional setup after loading the view.
    }
    //dismiss keyboard
    @objc func dismissKeyboard(){
        self.view.endEditing(true)
    }
    

    
    

    
    //creates the directory where we can store files
    func createDirectory(){
            
            
            let lDocumentsDirectoryURL = try! lFM.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true)
            
            print("***** in create DirectoryAction, the URL for 'Documents/' is...\n")
            print("***** \(lDocumentsDirectoryURL) \n")
            
            let lFolderNameURLWithPath = lDocumentsDirectoryURL.appendingPathComponent("MyFolder", isDirectory: true)
            
            do{
                try lFM.createDirectory(at: lFolderNameURLWithPath,
                                        withIntermediateDirectories: true,
                                        attributes: nil)
                
                self.theFolderNameURLWithPath = lFolderNameURLWithPath
            }catch let err as NSError{
                print("***** DANGER \(err) detectd when creating directory *****\n")
            }
            
        }
    
    //stores information in or myFolder
    //Finder -> Go -> Go to file -> ~/Library/Developer/CoreSimulator/Devices/
    //check console to find the rest of path, changes from time to time
    func createHighscoreFile(){
            let lFileNameURLWithPath = self.theFolderNameURLWithPath.appendingPathComponent("theUnicodeFiler.txt")
        do{
           
            try highestScore.description.write(to: lFileNameURLWithPath,
                                                      atomically: true,
                                                      encoding: String.Encoding.utf8)
            
            
            print("***** in createFileAction, the URL for the new file is ... \n")
            print("****** \(lFileNameURLWithPath) \n")
        }catch let err as NSError{
            print("****** DANGER \(err) detected when creating new file *****")
        }
        
        
    }
    
    func getDocumentDirectory() -> URL {
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    func readFile() -> Int{
        do {
        let newHighscore = try String(contentsOf: self.theFolderNameURLWithPath.appendingPathComponent("theUnicodeFiler.txt"))
            highestScore = Int(newHighscore)!
        
        } catch {
        print(error.localizedDescription)
        }
        return highestScore
    }
    
    
    
    
    

    
  
    
    func testLoad(){
        correctWord = myGuessTheWordModel.correctWord()   }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
