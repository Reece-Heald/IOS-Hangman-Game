//
//  Congrats scene.swift
//  GuessTheWord
//
//    Reece Heald - rnheald
//    Andrew Bathija - abathija
//    Max rodriguez - maxrodri
//    App Name: Guess The Word
//    Due Date: 5/5/22

import SpriteKit

class CongratsScene: SKScene {
 
   
    override func didMove(to view: SKView) {
       
        let congrats1 = SKSpriteNode(imageNamed: "congrats1")
        let congrats2 = SKSpriteNode(imageNamed: "congrats2")
        let congrats3 = SKSpriteNode(imageNamed: "congrats3")
        let congrats4 = SKSpriteNode(imageNamed: "congrats4")
        
        
        backgroundColor = SKColor.systemGreen
        let label = SKLabelNode()
        label.numberOfLines = 0
        label.text = "Congratulations,\nyou have the newest high score!"
        label.fontSize = 20
        label.fontColor = SKColor.black
        label.fontName = "Rockwall-Bold"
        label.fontSize = 24
        label.position = CGPoint(x: size.width/2, y: size.height/2)
        label.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.center
        label.verticalAlignmentMode = SKLabelVerticalAlignmentMode.center
        addChild(label)
        
        var textures:[SKTexture] = []
       
        
        for i in 1...4 {
            textures.append(SKTexture(imageNamed: "congrats\(i)"))
        }
        textures.append(textures[2])
        textures.append(textures[1])
        
        var congratsAnumation = SKAction.animate(withNormalTextures: textures, timePerFrame: 0.1)
       // addChild(congrats1)
     // congrats1.run(SKAction.repeatForever(congratsAnumation))
        
        
       // congrats.position = CGPoint(x: size.width/2, y: size.height/2)
          //addChild(congrats)
       }

    
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
}
