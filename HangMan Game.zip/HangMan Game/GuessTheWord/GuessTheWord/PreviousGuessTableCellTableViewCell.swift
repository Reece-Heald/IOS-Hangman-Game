//
//  PreviousGuessTableCellTableViewCell.swift
//  GuessTheWord
//
//    Reece Heald - rnheald
//    Andrew Bathija - abathija
//    Max rodriguez - maxrodri
//    App Name: Guess The Word
//    Due Date: 5/5/22

import UIKit

class PreviousGuessTableCell: UITableViewCell {


    @IBOutlet weak var howManyInWordLabel: UILabel!
    @IBOutlet weak var previousGuessLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //previousGuessLabel.text = "test guess label"
       // howManyInWordLabel.text = "test how many letter label"
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    

}
