//
//  HintViewController.swift
//  GuessTheWord
//
//    Reece Heald - rnheald
//    Andrew Bathija - abathija
//    Max rodriguez - maxrodri
//    App Name: Guess The Word
//    Due Date: 5/5/22

import UIKit

class HintViewController: UIViewController {
    
    let lAppDelegate = UIApplication.shared.delegate as! AppDelegate
    var myGuessTheWordModel: GuessTheWordModel!
 
    @IBOutlet weak var categoryHint: UILabel!
    @IBOutlet weak var letterHint: UILabel!
    @IBOutlet weak var hintDecrement: UILabel!
    
    @IBAction func categoryHintButton(_ sender: Any) {
    
        self.myGuessTheWordModel.hintsRemainingminus()
        self.categoryHint.text = myGuessTheWordModel.possibleCategories[myGuessTheWordModel.getRandIndex()]
        if self.myGuessTheWordModel.hintsLeft >= 1 {
            self.hintDecrement.text = String(self.myGuessTheWordModel.hintsLeft)
        }
        if self.myGuessTheWordModel.hintsLeft == 0 {
            self.hintDecrement.text = String(0)
            self.hintDecrement.backgroundColor = UIColor.red
        }
    }
    
    @IBAction func letterHintButton(_ sender: Any) {
        self.myGuessTheWordModel.hintsRemainingminus()
        self.letterHint.text = self.myGuessTheWordModel.letterHint(correctWord: self.myGuessTheWordModel.correctWord())
        if self.myGuessTheWordModel.hintsLeft >= 1 {
            self.hintDecrement.text = String(self.myGuessTheWordModel.hintsLeft)
        }
        if self.myGuessTheWordModel.hintsLeft == 0 {
            self.hintDecrement.text = String(0)
            self.hintDecrement.backgroundColor = UIColor.red
        }
    }
    
    override func viewDidLoad() {
        myGuessTheWordModel = lAppDelegate.myGuessTheWordModel
        self.hintDecrement.text = String(self.myGuessTheWordModel.hintsLeft)
        super.viewDidLoad()

        // Do any additional setup after loading the view.

    }

    override func viewWillAppear(_ animated: Bool) {
        myGuessTheWordModel = lAppDelegate.myGuessTheWordModel
        if self.myGuessTheWordModel.hintsLeft < 0 {
            self.myGuessTheWordModel.hintsLeft = 0
        }
        self.hintDecrement.text = String(self.myGuessTheWordModel.hintsLeft)
        self.hintDecrement.backgroundColor = UIColor.white
        self.categoryHint.text = "____________________________________"
        self.letterHint.text = "_________"
        if self.myGuessTheWordModel.hintsLeft == 0 {
            self.hintDecrement.backgroundColor = UIColor.red
        }
        super.viewDidLoad()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
