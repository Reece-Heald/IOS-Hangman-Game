//
//  GuessTheWordModel.swift
//  GuessTheWord
//
//    Reece Heald - rnheald
//    Andrew Bathija - abathija
//    Max rodriguez - maxrodri
//    App Name: Guess The Word
//    Due Date: 5/5/22
import Foundation

class GuessTheWordModel {
    
    var hintsLeft = 2
    
    var possibleWords : [String] = ["lizard", "dog", "college", "apple", "football", "basketball", "strawberry"]
    
    var numOfLettersInWord: [Int] = [6,3,7,5,8,10,3]
    
    var possibleCategories : [String] = ["reptile", "pet", "education","fruit", "sport", "sport", "fruit"]
    
    var previousGuesses : [String] = []
    
    var correctLetters: [Character] = []
    
    var countHowManyInWord = 0
    
    var randIndex = Int.random(in: 0...6)
    
    func getRandIndex() -> Int {
        return randIndex
    }
    
    func setRandIndex(){
        self.randIndex = Int.random(in: 0...6)
    }
    
    func correctWord() -> String {
        return possibleWords[randIndex]
    }
    
    func newWord() -> String {
        return possibleWords[randIndex]
    }
    
    func correctCategory(word: String) -> String {
       // var temp = find(possibleWords,word)
        var temp =  possibleWords.firstIndex(of: word)
        return possibleCategories[temp!]
    }

    func letterHint(correctWord: String) -> String {
        for char in correctWord {
            if (correctLetters.contains(char) == false) {
                return String(char)
        }
            else {
                return "You have already guessed every letter."
            }
    }
        return ""
    }
    
    func hintsRemainingminus() {
        hintsLeft = hintsLeft - 1
    }
    
    func setHintsRemaining() {
        self.hintsLeft = 2
    }
    
    
    func addPreviousGuess(guess: String){
        self.previousGuesses.append(guess)

    }
    
    func lettersCorrect (guess: String, correct : String) {
        for letter in guess {
            if (correct.contains(letter)) {
                correctLetters.append(letter)
            }
        }
    }
}
